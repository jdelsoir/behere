repo: jdelsoir/behere
branch: main
path: web/

## Last sync
date: 2026-08-15T00:00:00Z

### Updated in this project
- Rebuilt BeHERE as a map-first design: full-bleed map, five bands as pill overlays.
- Band content regrounded on the attached codebase (meta.json, sector.geojson, a grid shard, grid_fixture.txt) — no invented records.
- grid.js EPSG:3035 projection ported to draw the real 1 km GRD_NEWID cell; sector resolved by point-in-polygon as here.js does.
- Bands that have nothing baked say so in the repo's own copy instead of showing placeholder data.

## Screen map
| Screen | Built from |
| --- | --- |
| BeHERE Map.dc.html — map + Here band | web/data/&lt;nis&gt;/meta.json, web/data/21004/sector.geojson, web/app/here.js, web/app/grid.js, scripts/grid_fixture.txt |
| BeHERE Map.dc.html — Around band | web/app/around.js (ODS_REGISTRY, COPY) |
| BeHERE Map.dc.html — Go band | web/data/grid/1kmN3097E3924.json, web/app/geo.js (decodeShard), web/app/go.js |
| BeHERE Map.dc.html — Now band | web/app/now.js (DATASETS, WALLOON_AGENDA) |
| BeHERE Map.dc.html — Zoom out band | web/data/&lt;nis&gt;/meta.json (nuts3, dstr), web/data/meta.json (sources) |
